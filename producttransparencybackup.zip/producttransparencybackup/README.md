# producttransparency

To Display the Trasnparency of product
